function cambiarImagen(el) {
    $('#aside-login :hidden').fadeIn(750).removeClass('invisible');
    $(el).fadeOut(250);
}