function modalContrasena() {
    $(function() {$( "#dialog" ).dialog({
        modal: true,
    })});
}